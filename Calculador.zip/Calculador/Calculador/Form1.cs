﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculador
{
    public partial class Calculador : Form
    {
        public Calculador()
        {
            InitializeComponent();
        }

        

    private void Calculador_Load(object sender, EventArgs e)
        {

        }

        private void (object sender, EventArgs e)
        {

            private void btncalcular_Click(object sender, EventArgs e)
        {
            int varInteiro = int.Parse(txtInteiro.Text);
            float varDecimal = int.Parse(txtDecimal.Text);
            float resultado;

            //Soma;
            resultado = varInteiro + varDecimal;
                MessageBox.Show("Soma: " + resultado);

            //Subtração;
            resultado = varInteiro - varDecimal;
                MessageBox.Show("Subtração: " + resultado);

            //Multiplicação;
            resultado = txtInteiro * txtDecimal;
                MessageBox.Show("Multiplicação: " + resultado);

            //Divisão;
            resultado = txtInteiro / txtDecimal;
                MessageBox.Show("Divisão: " + resultado);
        }
    }
}
}
