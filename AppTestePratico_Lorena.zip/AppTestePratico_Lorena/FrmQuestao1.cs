﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_Lorena
{
    public partial class FrmQuestao1 : Form
    {
        public FrmQuestao1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela
            int qtdPaes = int.Parse(txtPaes.Text);
            int qtdBroas = int.Parse(txtPaes.Text);
            float total;


            // Fazer o cálculo
            total = qtdBroas * 1.50f + qtdPaes * 0.12f;


            //Mostrar resultado em uma label
            lblResultado.Text = "R$" + total;


        }
    }
}
