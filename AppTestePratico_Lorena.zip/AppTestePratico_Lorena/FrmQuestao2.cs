﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_Lorena
{
    public partial class FrmQuestao2 : Form
    {
        public FrmQuestao2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Pegar valores na tela

            int qntdCamisaP = int.Parse (txtCamisaP.Text);
            int qntdCamisaM = int.Parse (txtCamisaM.Text);
            int qntdCamisaG = int.Parse (txtCamisaG.Text);
            float total;


            // Fazer cálculo

            total = qntdCamisaP * 12f + qntdCamisaM * 14f + qntdCamisaG *22f;

           
            // Mostrar resultado
            lblResultado.Text = "R$" + total;
        }
    }
}
