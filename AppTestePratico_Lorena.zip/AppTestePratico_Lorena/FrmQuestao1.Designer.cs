﻿namespace AppTestePratico_Lorena
{
    partial class FrmQuestao1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblquestão1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblPaes = new System.Windows.Forms.Label();
            this.lblBroas = new System.Windows.Forms.Label();
            this.txtPaes = new System.Windows.Forms.TextBox();
            this.txtBroas = new System.Windows.Forms.TextBox();
            this.btncalcular = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(255)))), ((int)(((byte)(191)))));
            this.panel1.Controls.Add(this.lblquestão1);
            this.panel1.Location = new System.Drawing.Point(-13, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(820, 90);
            this.panel1.TabIndex = 0;
            // 
            // lblquestão1
            // 
            this.lblquestão1.AutoSize = true;
            this.lblquestão1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquestão1.Location = new System.Drawing.Point(44, 30);
            this.lblquestão1.Name = "lblquestão1";
            this.lblquestão1.Size = new System.Drawing.Size(139, 31);
            this.lblquestão1.TabIndex = 2;
            this.lblquestão1.Text = "Questão 1";
            this.lblquestão1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(255)))), ((int)(((byte)(191)))));
            this.panel2.Controls.Add(this.lblResultado);
            this.panel2.Location = new System.Drawing.Point(-1, 364);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(808, 88);
            this.panel2.TabIndex = 1;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(67, 24);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(153, 25);
            this.lblResultado.TabIndex = 0;
            this.lblResultado.Text = "Valor a pagar: ";
            // 
            // lblPaes
            // 
            this.lblPaes.AutoSize = true;
            this.lblPaes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaes.Location = new System.Drawing.Point(67, 140);
            this.lblPaes.Name = "lblPaes";
            this.lblPaes.Size = new System.Drawing.Size(181, 24);
            this.lblPaes.TabIndex = 2;
            this.lblPaes.Text = "Quantidade de pães";
            // 
            // lblBroas
            // 
            this.lblBroas.AutoSize = true;
            this.lblBroas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBroas.Location = new System.Drawing.Point(64, 181);
            this.lblBroas.Name = "lblBroas";
            this.lblBroas.Size = new System.Drawing.Size(187, 24);
            this.lblBroas.TabIndex = 3;
            this.lblBroas.Text = "Quantidade de broas";
            this.lblBroas.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtPaes
            // 
            this.txtPaes.Location = new System.Drawing.Point(293, 145);
            this.txtPaes.Name = "txtPaes";
            this.txtPaes.Size = new System.Drawing.Size(100, 20);
            this.txtPaes.TabIndex = 4;
            // 
            // txtBroas
            // 
            this.txtBroas.Location = new System.Drawing.Point(293, 185);
            this.txtBroas.Name = "txtBroas";
            this.txtBroas.Size = new System.Drawing.Size(100, 20);
            this.txtBroas.TabIndex = 5;
            // 
            // btncalcular
            // 
            this.btncalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(255)))), ((int)(((byte)(182)))));
            this.btncalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalcular.Location = new System.Drawing.Point(86, 239);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(127, 47);
            this.btncalcular.TabIndex = 6;
            this.btncalcular.Text = "CALCULAR";
            this.btncalcular.UseVisualStyleBackColor = false;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // FrmQuestao1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(198)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.txtBroas);
            this.Controls.Add(this.txtPaes);
            this.Controls.Add(this.lblBroas);
            this.Controls.Add(this.lblPaes);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FrmQuestao1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblquestão1;
        private System.Windows.Forms.Label lblPaes;
        private System.Windows.Forms.Label lblBroas;
        private System.Windows.Forms.TextBox txtPaes;
        private System.Windows.Forms.TextBox txtBroas;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}

