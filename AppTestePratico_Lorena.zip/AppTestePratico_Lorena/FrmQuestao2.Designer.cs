﻿namespace AppTestePratico_Lorena
{
    partial class FrmQuestao2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblquestao2 = new System.Windows.Forms.Label();
            this.lblCamisasP = new System.Windows.Forms.Label();
            this.lblCamisasM = new System.Windows.Forms.Label();
            this.lblCamisasG = new System.Windows.Forms.Label();
            this.txtCamisaP = new System.Windows.Forms.TextBox();
            this.txtCamisaM = new System.Windows.Forms.TextBox();
            this.txtCamisaG = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(246)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.lblquestao2);
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(807, 101);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(246)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.lblResultado);
            this.panel2.Location = new System.Drawing.Point(-2, 352);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(807, 100);
            this.panel2.TabIndex = 1;
            // 
            // lblquestao2
            // 
            this.lblquestao2.AutoSize = true;
            this.lblquestao2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquestao2.Location = new System.Drawing.Point(37, 30);
            this.lblquestao2.Name = "lblquestao2";
            this.lblquestao2.Size = new System.Drawing.Size(191, 42);
            this.lblquestao2.TabIndex = 0;
            this.lblquestao2.Text = "Questão 2";
            // 
            // lblCamisasP
            // 
            this.lblCamisasP.AutoSize = true;
            this.lblCamisasP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisasP.Location = new System.Drawing.Point(38, 135);
            this.lblCamisasP.Name = "lblCamisasP";
            this.lblCamisasP.Size = new System.Drawing.Size(206, 24);
            this.lblCamisasP.TabIndex = 2;
            this.lblCamisasP.Text = "Quantidade Camisas P:";
            // 
            // lblCamisasM
            // 
            this.lblCamisasM.AutoSize = true;
            this.lblCamisasM.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisasM.Location = new System.Drawing.Point(38, 177);
            this.lblCamisasM.Name = "lblCamisasM";
            this.lblCamisasM.Size = new System.Drawing.Size(210, 24);
            this.lblCamisasM.TabIndex = 3;
            this.lblCamisasM.Text = "Quantidade Camisas M:";
            // 
            // lblCamisasG
            // 
            this.lblCamisasG.AutoSize = true;
            this.lblCamisasG.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisasG.Location = new System.Drawing.Point(38, 218);
            this.lblCamisasG.Name = "lblCamisasG";
            this.lblCamisasG.Size = new System.Drawing.Size(208, 24);
            this.lblCamisasG.TabIndex = 4;
            this.lblCamisasG.Text = "Quantidade Camisas G:";
            // 
            // txtCamisaP
            // 
            this.txtCamisaP.Location = new System.Drawing.Point(267, 135);
            this.txtCamisaP.Name = "txtCamisaP";
            this.txtCamisaP.Size = new System.Drawing.Size(100, 20);
            this.txtCamisaP.TabIndex = 5;
            // 
            // txtCamisaM
            // 
            this.txtCamisaM.Location = new System.Drawing.Point(267, 177);
            this.txtCamisaM.Name = "txtCamisaM";
            this.txtCamisaM.Size = new System.Drawing.Size(100, 20);
            this.txtCamisaM.TabIndex = 6;
            // 
            // txtCamisaG
            // 
            this.txtCamisaG.Location = new System.Drawing.Point(267, 218);
            this.txtCamisaG.Name = "txtCamisaG";
            this.txtCamisaG.Size = new System.Drawing.Size(100, 20);
            this.txtCamisaG.TabIndex = 7;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(45, 32);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(183, 31);
            this.lblResultado.TabIndex = 0;
            this.lblResultado.Text = "Valor a pagar:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(196)))), ((int)(((byte)(255)))));
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(255, 274);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(112, 34);
            this.btnCalcular.TabIndex = 8;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmQuestao2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(255)))), ((int)(((byte)(182)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtCamisaG);
            this.Controls.Add(this.txtCamisaM);
            this.Controls.Add(this.txtCamisaP);
            this.Controls.Add(this.lblCamisasG);
            this.Controls.Add(this.lblCamisasM);
            this.Controls.Add(this.lblCamisasP);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FrmQuestao2";
            this.Text = "FrmQuestao2";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblquestao2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblCamisasP;
        private System.Windows.Forms.Label lblCamisasM;
        private System.Windows.Forms.Label lblCamisasG;
        private System.Windows.Forms.TextBox txtCamisaP;
        private System.Windows.Forms.TextBox txtCamisaM;
        private System.Windows.Forms.TextBox txtCamisaG;
        private System.Windows.Forms.Button btnCalcular;
    }
}