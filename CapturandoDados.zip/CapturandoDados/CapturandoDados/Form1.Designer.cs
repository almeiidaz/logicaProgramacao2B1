﻿namespace CapturandoDados
{
    partial class FrmDados
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDados));
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.txtBoleano = new System.Windows.Forms.TextBox();
            this.lblInteiro = new System.Windows.Forms.Label();
            this.lbltexto = new System.Windows.Forms.Label();
            this.lbldecimal = new System.Windows.Forms.Label();
            this.lblBoleano = new System.Windows.Forms.Label();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtInteiro
            // 
            this.txtInteiro.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInteiro.Location = new System.Drawing.Point(12, 43);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(188, 29);
            this.txtInteiro.TabIndex = 1;
            this.txtInteiro.TextChanged += new System.EventHandler(this.txtInteiro_TextChanged);
            // 
            // txtTexto
            // 
            this.txtTexto.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTexto.Location = new System.Drawing.Point(12, 118);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(188, 29);
            this.txtTexto.TabIndex = 2;
            this.txtTexto.TextChanged += new System.EventHandler(this.txtTexto_TextChanged);
            // 
            // txtDecimal
            // 
            this.txtDecimal.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimal.Location = new System.Drawing.Point(12, 203);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(188, 29);
            this.txtDecimal.TabIndex = 3;
            // 
            // txtBoleano
            // 
            this.txtBoleano.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoleano.Location = new System.Drawing.Point(12, 289);
            this.txtBoleano.Name = "txtBoleano";
            this.txtBoleano.Size = new System.Drawing.Size(188, 29);
            this.txtBoleano.TabIndex = 4;
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInteiro.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblInteiro.Location = new System.Drawing.Point(12, 18);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(64, 22);
            this.lblInteiro.TabIndex = 5;
            this.lblInteiro.Text = "Inteiro";
            // 
            // lbltexto
            // 
            this.lbltexto.AutoSize = true;
            this.lbltexto.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltexto.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbltexto.Location = new System.Drawing.Point(12, 93);
            this.lbltexto.Name = "lbltexto";
            this.lbltexto.Size = new System.Drawing.Size(54, 22);
            this.lbltexto.TabIndex = 6;
            this.lbltexto.Text = "Texto";
            // 
            // lbldecimal
            // 
            this.lbldecimal.AutoSize = true;
            this.lbldecimal.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldecimal.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbldecimal.Location = new System.Drawing.Point(9, 178);
            this.lbldecimal.Name = "lbldecimal";
            this.lbldecimal.Size = new System.Drawing.Size(75, 22);
            this.lbldecimal.TabIndex = 7;
            this.lbldecimal.Text = "Decimal";
            // 
            // lblBoleano
            // 
            this.lblBoleano.AutoSize = true;
            this.lblBoleano.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBoleano.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblBoleano.Location = new System.Drawing.Point(12, 264);
            this.lblBoleano.Name = "lblBoleano";
            this.lblBoleano.Size = new System.Drawing.Size(76, 22);
            this.lblBoleano.TabIndex = 8;
            this.lblBoleano.Text = "Boleano";
            // 
            // btnEnviar
            // 
            this.btnEnviar.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviar.ForeColor = System.Drawing.Color.Coral;
            this.btnEnviar.Location = new System.Drawing.Point(13, 349);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(71, 27);
            this.btnEnviar.TabIndex = 9;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = true;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(106, 349);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(70, 27);
            this.btnLimpar.TabIndex = 10;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // FrmDados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(430, 450);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.lblBoleano);
            this.Controls.Add(this.lbldecimal);
            this.Controls.Add(this.lbltexto);
            this.Controls.Add(this.lblInteiro);
            this.Controls.Add(this.txtBoleano);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.txtInteiro);
            this.ForeColor = System.Drawing.Color.Coral;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmDados";
            this.Text = "FrmDados";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.TextBox txtBoleano;
        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.Label lbltexto;
        private System.Windows.Forms.Label lbldecimal;
        private System.Windows.Forms.Label lblBoleano;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Button btnLimpar;
    }
}

